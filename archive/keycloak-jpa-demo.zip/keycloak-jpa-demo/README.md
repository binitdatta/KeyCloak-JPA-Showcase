# keycloak-jpa-demo

Spring Boot 3.5.9 reference app demonstrating:
1. Spring Data JPA over an ecommerce MySQL 8 schema — 1:1, 1:many, and many:many
   relationships with full annotations.
2. Keycloak 26 client authentication mechanisms — Signed JWT, X509 Certificate,
   Signed JWT with Client Secret, and Capability Config (Authorization Services,
   Device Grant, CIBA).
3. A custom Keycloak Client Authenticator SPI provider.
4. A custom First Broker Login flow that extends "Create User If Unique" to call
   this app's REST API as an external identity source, plus a Post-Login Flow
   step that provisions realm roles/groups.
5. A Bootstrap 5 "Electric Bright Blue" themed site with a Training dropdown —
   one page per concept, written as a YouTube recording script.

## Project layout

```
keycloak-jpa-demo/
  pom.xml                          Spring Boot app
  src/main/java/com/havi/demo/     entities, repositories, controllers, security config
  src/main/resources/
    application.yml
    templates/                     Thymeleaf: navbar fragment, JPA pages, 8 training pages
    static/css/bright-blue.css     your uploaded theme
  db/
    schema.sql                     DBA-owned DDL for ecommerce_demo
    seed-data.sql                  seed rows exercising every relationship
  keycloak/
    realm-export.json              realm with 6 clients + custom flow wiring
  custom-providers/
    client-authenticator/          Keycloak SPI: custom Client Authenticator
    first-broker-login/            Keycloak SPI: extended Create-User-If-Unique + Post-Login provisioning
```

## 1. Database setup

```bash
mysql -u root -p < db/schema.sql
mysql -u root -p < db/seed-data.sql
```

Default local credentials assumed in `application.yml`: `root` / `localroot`
against `jdbc:mysql://localhost:3306/ecommerce_demo`.

## 2. Keycloak setup

Requires Keycloak 26.x running locally (default `http://localhost:8080`).

```bash
# from the Keycloak distribution directory
bin/kc.sh start-dev
```

Import the realm (admin console: **Create Realm → Browse → select
`keycloak/realm-export.json`**, or via the Admin CLI/REST API). This creates:

- `jpa-demo-web` — the Thymeleaf app's own confidential client (client-secret)
- `signed-jwt-client` — Episode A (`client-jwt`)
- `x509-cert-client` — Episode B (`client-x509`)
- `signed-jwt-secret-client` — Episode C (`client-secret-jwt`)
- `capability-demo-client` — Episode D (Authorization Services + Device Grant + CIBA on)
- `havi-secret-header-client` — Episode E1, authenticated by the custom provider below
- an identity provider (`havi-legacy-broker`) and the `havi-first-broker-login` flow
  definition used in Episodes E2/E3 (placeholder OIDC broker config — point
  `authorizationUrl` / `tokenUrl` / `userInfoUrl` at a real broker before using it live)

**X509 and Signed JWT need real key material** the JSON export can't carry —
generate a keypair/certificate and update `jwks.url` / `x509.subjectdn` after
import, per the steps on the `/training/signed-jwt` and `/training/x509-certificate`
pages.

## 3. Build and run the Spring Boot app

```bash
mvn -f pom.xml clean spring-boot:run
```

App comes up on `http://localhost:8091`. `/` is public; `/jpa/**` requires a
Keycloak login (redirects to `/oauth2/authorization/keycloak`); `/training/**`
is public so it works as a shareable recording reference; `/api/auth/**` is
public (called server-to-server by the Keycloak SPI, see below).

## 4. Build and deploy the two Keycloak SPI provider JARs

Each provider module is **its own Maven project** — Keycloak SPI providers
deploy as standalone JARs dropped into Keycloak's `providers/` directory, never
bundled inside the Spring Boot app.

```bash
cd custom-providers/client-authenticator
mvn clean package
cp target/havi-custom-client-authenticator.jar $KEYCLOAK_HOME/providers/

cd ../first-broker-login
mvn clean package
cp target/havi-first-broker-login-ext.jar $KEYCLOAK_HOME/providers/

cd $KEYCLOAK_HOME
bin/kc.sh build
bin/kc.sh start-dev
```

After the rebuild:
- **Havi Secret Header** appears in every client's Credentials → Client
  Authenticator dropdown (used by `havi-secret-header-client` in the realm export).
- **Havi Create User If Unique (Ext)** and **Havi Post-Login Role/Group
  Provisioning** appear as swappable executions when you duplicate the
  built-in *First broker login* flow (Keycloak's built-in flows are read-only,
  so duplicate it first, then swap executions — the realm export already
  defines the resulting flow as `havi-first-broker-login`).

> The Maven POMs for both SPI modules compile against
> `org.keycloak:keycloak-server-spi*` / `keycloak-services` 26.0.7 with
> `provided` scope (these classes ship inside the Keycloak server itself).
> A couple of `AbstractIdpAuthenticator` hook method names have shifted
> across Keycloak minor versions — if `mvn package` reports a signature
> mismatch, check the installed Keycloak version's javadoc for the exact
> `authenticateImpl` / `actionImpl` signatures and adjust the override.

## 5. Walk through the training site

Start at `http://localhost:8091/training` — each of the 8 pages is a
self-contained script (goal, prerequisites, on-screen steps, wrap-up line)
matching the episode list above, cross-linked next/previous.

## 6. Walk through the JPA pages

`http://localhost:8091/jpa/customers` and `http://localhost:8091/jpa/products`
render the live entity graph: 1:1 profile/payment, 1:many orders/items,
many:many product tags — each page links back to the matching annotation
in `/training/jpa-relationships`.
