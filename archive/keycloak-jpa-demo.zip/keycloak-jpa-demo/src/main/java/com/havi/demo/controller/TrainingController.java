package com.havi.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * One route per training article. Each maps to a static-content Thymeleaf
 * page under templates/training/ written as a step-by-step script for a
 * YouTube walkthrough.
 */
@Controller
public class TrainingController {

    @GetMapping("/training")
    public String trainingIndex() {
        return "training/index";
    }

    @GetMapping("/training/signed-jwt")
    public String signedJwt() {
        return "training/signed-jwt";
    }

    @GetMapping("/training/x509-certificate")
    public String x509Certificate() {
        return "training/x509-certificate";
    }

    @GetMapping("/training/signed-jwt-client-secret")
    public String signedJwtClientSecret() {
        return "training/signed-jwt-client-secret";
    }

    @GetMapping("/training/capability-config")
    public String capabilityConfig() {
        return "training/capability-config";
    }

    @GetMapping("/training/custom-client-authenticator")
    public String customClientAuthenticator() {
        return "training/custom-client-authenticator";
    }

    @GetMapping("/training/first-broker-login")
    public String firstBrokerLogin() {
        return "training/first-broker-login";
    }

    @GetMapping("/training/post-login-flow")
    public String postLoginFlow() {
        return "training/post-login-flow";
    }

    @GetMapping("/training/jpa-relationships")
    public String jpaRelationships() {
        return "training/jpa-relationships";
    }
}
