package com.havi.demo.repository;

import com.havi.demo.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("select distinct p from Product p left join fetch p.tags where p.productId = :id")
    Optional<Product> findWithTags(Long id);

    List<Product> findByCategory_CategoryId(Long categoryId);

    @Query("select distinct p from Product p join p.tags t where t.tagName = :tagName")
    List<Product> findByTagName(String tagName);
}
