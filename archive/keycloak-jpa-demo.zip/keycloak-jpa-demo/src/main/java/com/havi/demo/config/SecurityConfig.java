package com.havi.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
import org.springframework.security.oauth2.client.oidc.web.logout.OidcClientInitiatedLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Two concerns are demonstrated side by side:
 *  1. Browser login (Authorization Code + PKCE via oauth2Login) for the
 *     Thymeleaf UI — training pages and JPA pages.
 *  2. A stateless JWT resource-server chain under /api/** for the REST
 *     endpoints used by the First-Broker-Login custom authenticator
 *     (see custom-providers/first-broker-login).
 *
 * Per project convention: PKCE public clients for UIs would normally be used
 * from a pure SPA; here the Thymeleaf app is itself a confidential
 * "web application" client (jpa-demo-web) using the standard
 * authorization_code grant, which Spring's oauth2Login always drives with
 * PKCE when the provider supports it.
 */
@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http,
                                            ClientRegistrationRepository clientRegistrationRepository) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/", "/css/**", "/js/**", "/webjars/**", "/training/**", "/actuator/health").permitAll()
                .requestMatchers("/api/auth/**").permitAll() // used by the Keycloak First-Broker-Login authenticator
                .requestMatchers("/jpa/**").authenticated()
                .anyRequest().authenticated()
            )
            .oauth2Login(oauth2 -> oauth2.loginPage("/oauth2/authorization/keycloak"))
            .oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt)
            .logout(logout -> logout.logoutSuccessHandler(oidcLogoutSuccessHandler(clientRegistrationRepository)));

        return http.build();
    }

    private OidcClientInitiatedLogoutSuccessHandler oidcLogoutSuccessHandler(
            ClientRegistrationRepository clientRegistrationRepository) {
        OidcClientInitiatedLogoutSuccessHandler handler =
                new OidcClientInitiatedLogoutSuccessHandler(clientRegistrationRepository);
        handler.setPostLogoutRedirectUri("{baseUrl}");
        return handler;
    }
}
