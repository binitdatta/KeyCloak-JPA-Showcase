package com.havi.ciba;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

/**
 * This is the URI you configure Keycloak's ciba-http-auth-channel provider
 * to call (see the --spi-ciba-auth-channel-... startup flag). Keycloak POSTs
 * here, server-to-server, immediately after accepting a
 * POST /ext/ciba/auth request — this is the "notify the Authentication
 * Device" step of the CIBA flow.
 *
 * Per Keycloak's documented contract, the request body is
 * application/x-www-form-urlencoded with fields including login_hint,
 * scope, is_consent_required, binding_message, and acr_values, and the
 * Authorization header carries a bearer token that MUST be echoed back,
 * unchanged, on our later callback (see KeycloakCibaCallbackService).
 *
 * NOTE: this endpoint's exact expected response has not been verified
 * against a live Keycloak 26 instance from this environment — it returns a
 * plain 200 with no body, which matches the documented "fire and forget,
 * decision comes later via callback" behavior. If Keycloak's server log
 * shows anything other than a clean delivery when you test this, paste it
 * and we'll adjust the response shape.
 */
@RestController
public class CibaNotifyController {

    private static final Logger LOG = LoggerFactory.getLogger(CibaNotifyController.class);

    private final PendingRequestStore store;

    public CibaNotifyController(PendingRequestStore store) {
        this.store = store;
    }

    @PostMapping(value = "/ciba/notify", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public ResponseEntity<Void> notify(@RequestHeader(HttpHeaders.AUTHORIZATION) String authorizationHeader,
                                        @RequestBody MultiValueMap<String, String> form) {

        String bearerToken = authorizationHeader.replaceFirst("(?i)^Bearer\\s+", "");
        String loginHint = form.getFirst("login_hint");
        String scope = form.getFirst("scope");
        String bindingMessage = form.getFirst("binding_message");

        LOG.info("Received CIBA notification: login_hint={}, scope={}, binding_message={}",
                loginHint, scope, bindingMessage);

        store.set(new PendingCibaRequest(bearerToken, loginHint, scope, bindingMessage, Instant.now()));

        return ResponseEntity.ok().build();
    }
}
