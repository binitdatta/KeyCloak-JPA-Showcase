# Deploying entra-broker-sync-ext

## 1. Database
Run db/entra-sync-schema.sql against your keycloak_jpa_demo MySQL 8 schema
before any Entra login test.

## 2. Build
    cd entra-broker-sync-ext
    mvn clean package

## 3. Deploy to Keycloak
    cp target/havi-entra-broker-sync-ext.jar $KEYCLOAK_HOME/providers/
    cp ~/.m2/repository/com/mysql/mysql-connector-j/8.4.0/mysql-connector-j-8.4.0.jar $KEYCLOAK_HOME/providers/
    cd $KEYCLOAK_HOME
    bin/kc.sh build

## 4. Start Keycloak, then confirm registration
Authentication -> Flows -> any flow -> Add execution. The dropdown should
list "Havi Entra Create User (Ext)" and "Havi Entra Post-Login Role/Group
Sync". If either is missing, the META-INF/services file didn't make it into
the JAR -- verify with:
    jar tf target/havi-entra-broker-sync-ext.jar | grep META-INF/services

## 5. Wire the flows
- First Login Flow: duplicate the built-in "first broker login" flow, name it
  havi-entra-first-broker-login, swap its "Create User If Unique" step for
  "Havi Entra Create User (Ext)".
- Post Login Flow: create a new top-level flow havi-entra-post-login with a
  single REQUIRED execution: "Havi Entra Post-Login Role/Group Sync".
- On the entra-saml Identity Provider's Advanced tab, set First Login Flow
  and Post Login Flow to the two flows above.

## 6. DB credentials
EntraFblConstants.java hardcodes JDBC_URL / JDBC_USER / JDBC_PASSWORD for
this training lab. Edit that file and rebuild if your MySQL credentials
differ from root/changeit on localhost:3306.
